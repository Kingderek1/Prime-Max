const Map<String, String> deGR = {
  'privacy_policy': "Datenschutz-Bestimmungen",
};
