const Map<String, String> ptPO = {'privacy_policy': "Política de Privacidade"};
